// UK lang variables

tinyMCELang['lang_insert_advhr_desc']    = 'Insert / edit Horizontale Rule'
tinyMCELang['lang_insert_advhr_width']   = 'Width';
tinyMCELang['lang_insert_advhr_size']    = 'Height';
tinyMCELang['lang_insert_advhr_noshade'] = 'No shadow';
