//IT lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Inserisci una emoticon';
tinyMCELang['lang_emotions_desc'] = 'Emoticon';

