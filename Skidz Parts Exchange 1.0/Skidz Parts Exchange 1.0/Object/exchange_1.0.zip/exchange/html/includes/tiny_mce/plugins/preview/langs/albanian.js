// UK lang variables

tinyMCELang['lang_preview_desc'] = 'Preview';
