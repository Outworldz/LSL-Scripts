// DE lang variables by Tobias Heer

tinyMCELang['lang_preview_desc'] = 'Vorschau';
