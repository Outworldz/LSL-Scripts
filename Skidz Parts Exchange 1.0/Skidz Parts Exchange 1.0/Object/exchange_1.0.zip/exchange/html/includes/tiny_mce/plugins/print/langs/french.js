// French lang variables by Laurent Dran

tinyMCELang['lang_print_desc'] = 'Imprimer';
