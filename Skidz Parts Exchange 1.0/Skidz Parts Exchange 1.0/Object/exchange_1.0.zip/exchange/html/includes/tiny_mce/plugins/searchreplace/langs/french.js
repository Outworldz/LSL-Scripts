// Franch lang variables by Laurent Dran

tinyMCELang['lang_searchreplace_search_desc'] = 'Trouver';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'Trouver encore';
tinyMCELang['lang_searchreplace_replace_desc'] = 'Trouver/Remplacer';
tinyMCELang['lang_searchreplace_notfound'] = 'Votre recherche a &eacute;t&eacute; compl&eacute;&eacute;. La recherche de la chaine pourra ne pas aboutir.';
tinyMCELang['lang_searchreplace_search_title'] = 'Trouver';
tinyMCELang['lang_searchreplace_replace_title'] = 'Trouver/Remplacer';
tinyMCELang['lang_searchreplace_allreplaced'] = 'Toutes les occurences de la chaine ont &eacute;t&eacute; remplc&eacute;es.';
tinyMCELang['lang_searchreplace_findwhat'] = 'Trouver le mot';
tinyMCELang['lang_searchreplace_replacewith'] = 'Remplacer avec';
tinyMCELang['lang_searchreplace_direction'] = 'Direction';
tinyMCELang['lang_searchreplace_up'] = 'Haut';
tinyMCELang['lang_searchreplace_down'] = 'Base';
tinyMCELang['lang_searchreplace_case'] = 'Respecter la casse';
tinyMCELang['lang_searchreplace_findnext'] = 'Trouver le prochain';
tinyMCELang['lang_searchreplace_replace'] = 'Remplacer';
tinyMCELang['lang_searchreplace_replaceall'] = 'Remplacer tout';
tinyMCELang['lang_searchreplace_cancel'] = 'Annuler';
